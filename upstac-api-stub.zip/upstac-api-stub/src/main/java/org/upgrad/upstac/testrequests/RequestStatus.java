package org.upgrad.upstac.testrequests;

public enum RequestStatus {

    INITIATED,LAB_TEST_IN_PROGRESS,LAB_TEST_COMPLETED,DIAGNOSIS_IN_PROCESS,COMPLETED
}

