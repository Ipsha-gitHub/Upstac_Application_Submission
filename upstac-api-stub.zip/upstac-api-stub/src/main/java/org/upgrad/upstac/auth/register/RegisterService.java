package org.upgrad.upstac.auth.register;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.upgrad.upstac.exception.AppException;
import org.upgrad.upstac.users.User;
import org.upgrad.upstac.users.UserService;
import org.upgrad.upstac.users.roles.UserRole;
import org.upgrad.upstac.users.models.AccountStatus;

import java.time.LocalDateTime;

import static org.upgrad.upstac.shared.DateParser.getDateFromString;


@Service
public class RegisterService {

    @Autowired
    private UserService userService;


    private static final Logger log = LoggerFactory.getLogger(RegisterService.class);


    public User addUser(RegisterRequest registerRequest) {


        User user = new User();


/*      User should be validated before registration.
                the username , email and phone number should be unique (i.e should throw AppException if the RegisterRequest has the same username or email or phone number)
                    hint:
                        userService.findByUserName
                        userService.findByEmail
                        userService.findByPhoneNumber

         A new User Object should be created with same details as registerRequest
                password should be encrypted with help of   userService.toEncrypted
                roles should be set with help of  userService.getRoleFor(UserRole.USER)
                status should be set to AccountStatus.APPROVED

        And finally
            Call userService.saveInDatabase to save the new user and return the saved user
*/

        if(null != userService.findByUserName(registerRequest.getUserName()) || null != userService.findByEmail(registerRequest.getEmail())
                || null != userService.findByPhoneNumber(registerRequest.getPhoneNumber())){
            throw new AppException("Please check the user details. Username, EmailID and Phone number must be unique.");
        }else{
            user.setUserName(registerRequest.getUserName());
            user.setPassword(userService.toEncrypted(registerRequest.getPassword()));
            user.setCreated(LocalDateTime.now());
            user.setUpdated(LocalDateTime.now());
            user.setAddress(registerRequest.getAddress());
            user.setFirstName(registerRequest.getFirstName());
            user.setLastName(registerRequest.getLastName());
            user.setEmail(registerRequest.getEmail());
            user.setRoles(userService.getRoleFor(UserRole.USER));
            user.setPhoneNumber(registerRequest.getPhoneNumber());
            user.setPinCode(registerRequest.getPinCode());
            user.setGender(registerRequest.getGender());
            user.setAddress(registerRequest.getAddress());
            user.setDateOfBirth(getDateFromString(registerRequest.getDateOfBirth()));
            user.setStatus(AccountStatus.APPROVED);
            User updatedUser = userService.saveInDatabase(user);


            return updatedUser;
        }

       //throw new AppException("Method Not Implemented");
    }

    public User addDoctor(RegisterRequest registerRequest) {

        User user = new User();
/*      Doctor should be validated before registration.
                the username , email and phone number should be unique (i.e should throw AppException if the RegisterRequest has the same username or email or phone number)
                    hint:
                        userService.findByUserName
                        userService.findByEmail
                        userService.findByPhoneNumber

         A new User Object should be created with same details as registerRequest
                password should be encrypted with help of   userService.toEncrypted
                roles should be set with help of  userService.getRoleFor(UserRole.DOCTOR)
                status should be set to AccountStatus.INITIATED

        And finally
            Call userService.saveInDatabase to save the newly registered doctor and return the saved value
*/
        if(null != userService.findByUserName(registerRequest.getUserName()) || null != userService.findByEmail(registerRequest.getEmail())
                || null != userService.findByPhoneNumber(registerRequest.getPhoneNumber())){
            throw new AppException("Please check the user details. Username, EmailID and Phone number must be unique.");
        }else{
            user.setUserName(registerRequest.getUserName());
            user.setPassword(userService.toEncrypted(registerRequest.getPassword()));
            user.setCreated(LocalDateTime.now());
            user.setUpdated(LocalDateTime.now());
            user.setAddress(registerRequest.getAddress());
            user.setFirstName(registerRequest.getFirstName());
            user.setLastName(registerRequest.getLastName());
            user.setEmail(registerRequest.getEmail());
            user.setRoles(userService.getRoleFor(UserRole.DOCTOR));
            user.setPhoneNumber(registerRequest.getPhoneNumber());
            user.setPinCode(registerRequest.getPinCode());
            user.setGender(registerRequest.getGender());
            user.setAddress(registerRequest.getAddress());
            user.setDateOfBirth(getDateFromString(registerRequest.getDateOfBirth()));
            user.setStatus(AccountStatus.INITIATED);
            User updatedUser = userService.saveInDatabase(user);


            return updatedUser;
        }

        //throw new AppException("Method Not Implemented");
    }


    public User addTester(RegisterRequest registerRequest) {

        User user = new User();
/*      Tester should be validated before registration.
                the username , email and phone number should be unique (i.e should throw AppException if the RegisterRequest has the same username or email or phone number)
                    hint:
                        userService.findByUserName
                        userService.findByEmail
                        userService.findByPhoneNumber

         A new User Object should be created with same details as registerRequest
                password should be encrypted with help of   userService.toEncrypted
                roles should be set with help of  userService.getRoleFor(UserRole.TESTER)
                status should be set to AccountStatus.INITIATED

        And finally
            Call userService.saveInDatabase to save newly registered tester and return the saved value
*/
        if(null != userService.findByUserName(registerRequest.getUserName()) || null != userService.findByEmail(registerRequest.getEmail())
                || null != userService.findByPhoneNumber(registerRequest.getPhoneNumber())){
            throw new AppException("Please check the user details. Username, EmailID and Phone number must be unique.");
        }else{
            user.setUserName(registerRequest.getUserName());
            user.setPassword(userService.toEncrypted(registerRequest.getPassword()));
            user.setCreated(LocalDateTime.now());
            user.setUpdated(LocalDateTime.now());
            user.setAddress(registerRequest.getAddress());
            user.setFirstName(registerRequest.getFirstName());
            user.setLastName(registerRequest.getLastName());
            user.setEmail(registerRequest.getEmail());
            user.setRoles(userService.getRoleFor(UserRole.TESTER));
            user.setPhoneNumber(registerRequest.getPhoneNumber());
            user.setPinCode(registerRequest.getPinCode());
            user.setGender(registerRequest.getGender());
            user.setAddress(registerRequest.getAddress());
            user.setDateOfBirth(getDateFromString(registerRequest.getDateOfBirth()));
            user.setStatus(AccountStatus.INITIATED);
            User updatedUser = userService.saveInDatabase(user);


            return updatedUser;
        }

        //throw new AppException("Method Not Implemented");
    }
}
